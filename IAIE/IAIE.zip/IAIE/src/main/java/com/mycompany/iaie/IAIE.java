/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.iaie;

import java.io.IOException;


/**
 *
 * @author cr249
 */
public class IAIE {

    public static void main(String[] args) throws IOException {
        repositorioClientes clientes = new repositorioClientes();
        Moloni mol = new Moloni();
        janelaClientes jc = new janelaClientes(clientes, mol);
        jc.setVisible(true);
    }
}
